<?php
  // Crea una sesión
  session_start();
  // Si se valida correctamente, contendrá el valor introducido en el form.
  if(!isset( $_SESSION["token"])){ 
     $_SESSION["token"] = "";
  }   
?>
<!DOCTYPE html>
<!--
Ejemplo para validar usurios aplicacion REST y el creat TOKEN JWT
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
<body>
<form name="autenticar" method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" >
    <label>Usuario:    </label> <input type="text" name="usuario"><br>
    <label>Contraseña: </label> <input type="password" name="passwd"><br>
    <input type="submit" name="validar" value="Login">
    <input type="submit" name="validartoken" value="Validar Token">
    <input type="reset" name="cancelar" value="Cancelar">
</form>        

<?php
// Formulario para enviar al servidor REST
  include("curl_conexion.php");
  include("config.php");  
  $error_validacion= NULL;
  
  if(isset($_REQUEST["validar"])){
    if(isset($_REQUEST["usuario"]) && isset($_REQUEST["passwd"])){
        $usuario = filter_input(INPUT_POST, "usuario", FILTER_SANITIZE_STRING);
        $passwd = filter_input(INPUT_POST, "passwd", FILTER_SANITIZE_STRING);
        //Encripta el password
        $passwd = password_hash($passwd, PASSWORD_BCRYPT);
        $url = _URL_SERVIDOR_ . "index.php?usuario=" . $usuario . "&passwd=" . $passwd;
        $response = curl_conexion($url, "GET");
        $resp = json_decode($response);
        if($resp->status === "200"){
           $_SESSION["token"] = $resp->valor; 
           header("Location: bienvenida.php");
           exit;
        }
        else{
           $error_validacion= $resp->valor . "<br>";
           echo $error_validacion;
        }
    } // usuario y passwd 
  } // validar
  if(isset($_REQUEST["validartoken"])){
    $url = _URL_SERVIDOR_ . "index.php?validarToken=" . "valida";
    $response = curl_conexion($url, "GET", $_SESSION["token"]);
    $resp = json_decode($response);
    if($resp->status === "200"){
      header("Location: bienvenida.php");
      exit;
   }
   else{
      $error_validacion= $resp->status . " Error: " . $resp->valor . "<br>";
      echo $error_validacion;
   }
  }  
?>
</body>
</html>
