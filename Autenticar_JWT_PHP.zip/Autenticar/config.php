<?php
DEFINE("_URL_SERVIDOR_", "http://localhost/toni/Autenticar/");

$credenciales = ['toni' => '1234', 'admin' => 'admin'];
