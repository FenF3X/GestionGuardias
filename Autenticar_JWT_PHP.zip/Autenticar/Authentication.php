<?php

  include "vendor/firebase/php-jwt/src/JWTExceptionWithPayloadInterface.php";
  include "vendor/firebase/php-jwt/src/SignatureInvalidException.php";
  //include "vendor/firebase/php-jwt/src/ExpiredException.php"; 
  include "vendor/firebase/php-jwt/src/JWT.php";
  include "vendor/firebase/php-jwt/src/Key.php";
  
  
  class Authentication {  
    private $decodedToken = null;
    
    private $jwtKey = "123.IESjc.zzz";
       
    public function getDecodedToken() {
        return $this->decodedToken;
    }
    /**
    * Valida que en la cabecera HTTP "Authorization" haya un token válido
    * @return Mensaje de error (vacío si todo ha ido bien)
    */
    public function validaToken() {
        $error = '';
        if(!array_key_exists('Authorization',getallheaders())) {
            $error = 'No se ha iniciado sesión en la aplicación';
        } 
        else {
            $authorization = getallheaders()['Authorization'];
            $trozos = explode(' ', $authorization);
            $auth = $trozos[1]; // Normalmente recibimos 'Bearer token'
            try {
                 $decoded = \Firebase\JWT\JWT::decode($auth, new \Firebase\JWT\Key($this->jwtKey, 'HS256'));     
            } catch(\Firebase\JWT\SignatureInvalidException $e) {
                 $error = 'No se ha iniciado sesión en la aplicación';
            } //catch(\Firebase\JWT\ExpiredException $e) {
            catch(Exception $e) {    
                 $error = 'Excepcion: sesión caducada';
            }
        }
        if($error === '') {
            $this->decodedToken = $decoded;
        }
        return $error;
    }
    
    /**
    * Genera un token para la autenticación del usuario en la aplicación
    * @param $usuario Objeto del modelo con los datos del usuario autenticado
    * @return Token generado con JWT. Caduca al mes.
    */
    public function generaToken($usuario) {
        $tiempo = time();
        //$token = JWT::prova();
        $token = \Firebase\JWT\JWT::encode(
        [
            'exp' => $tiempo + 60, // 1 minuto -- 60*60, // Caduca en una hora
            'id' => $usuario,
            'rol' => 'profe',
        ],
        $this->jwtKey, // Clave JWT
        'HS256'  // Algoritmo de codificación del token
        ); 
        return $token;
    }
}
?>