
<?php

/* 
 * 
 * Aplicación de validación y crea token JWT servicios Web REST
 * Servidor REST
 * 
 */
//include 'funcion_conexion_bd.php'; 
include 'config.php'; // Tiene un array con usuarios $credenciales
include 'Authentication.php'; // Clase para gestionar los token JWT

$metodo = $_SERVER['REQUEST_METHOD'];

$auth = new Authentication();

switch($metodo){
    case 'GET':
        if(isset($_REQUEST['usuario']) && isset($_REQUEST['passwd'])){
            $usuario = filter_input(INPUT_GET, 'usuario',FILTER_SANITIZE_STRING);
            $passwd = filter_input(INPUT_GET, 'passwd',FILTER_SANITIZE_STRING);
            if(array_key_exists($usuario, $credenciales)) {
              // Comprueba el password encriptado
              if(password_verify($credenciales[$usuario], $passwd)){
                $token = $auth->generaToken($usuario);
                $con_bd = ["status" => "200", "valor" => $token];
              }
              else {
                $con_bd = ["status" => "401", "valor" => "Password incorrecto"];
              }
            }
            else {
              $con_bd = ["status" => "401", "valor" => "Usuario incorrecto"];  
            }    
            echo json_encode($con_bd, TRUE); 
        } //if(isset
      
        if(isset($_REQUEST['validarToken'])){ // Obtiene el dato del token
          $error = $auth->validaToken();
          if(strlen($error) > 0) { // Token error 
             $res = ["status" => "401", "valor" => "No está autenticado - " . $error];
          }
          else{
             $usu = $auth->getDecodedToken();
             $res = ["status" => "200", "valor" => $usu]; // Obtiene el dato del token 
          }
          echo json_encode($res, TRUE);
        }   
        break;        
}
?>