<?php
  // Reactiva la sesión iniciada 
  session_start();

  include("curl_conexion.php");
  include("config.php");
  
  $url = _URL_SERVIDOR_ . "index.php?validarToken=" . "valida";
  $response = curl_conexion($url, "GET", $_SESSION["token"]);
  $resp = json_decode($response);
  
  if($resp->status === "200"){
     echo "Usuario: " . $resp->valor->id . " rol: " . $resp->valor->rol  . "<br>";     
  }
  else{
     $error_validacion= $resp->valor . "<br>";
     echo "Error al decodificar token: " . $resp->status . "  " . $error_validacion ;
  }
  echo "<a href='cliente.php'>Volver</a>";
?>

